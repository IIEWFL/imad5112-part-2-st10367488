package com.example.calculatorapp_st10367488

import android.annotation.SuppressLint
import android.icu.lang.UCharacter.DecompositionType.SQUARE
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import java.math.BigDecimal
import java.math.RoundingMode
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {

    private var Digit1: TextView? = null
    private var Digit2: TextView? = null
    private var Result: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Digit1 = findViewById(R.id.Digit1)
        Digit2 = findViewById(R.id.Digit2)
        Result = findViewById(R.id.Result)

        val additionBtn = findViewById<Button>(R.id.additionBtn)
        val subtractionBtn = findViewById<Button>(R.id.subtractionBtn)
        val multiplicationBtn = findViewById<Button>(R.id.multiplicationBtn)
        val divisionBtn = findViewById<Button>(R.id.divisionBtn)
        val squareRootBtn = findViewById<Button>(R.id.squareRootBtn)
        val powerBtn = findViewById<Button>(R.id.powerBtn)


        additionBtn.setOnClickListener()
        {
            add()
        }
        subtractionBtn.setOnClickListener()
        {
            subtract()
        }
        multiplicationBtn.setOnClickListener()
        {
            multiply()
        }
        divisionBtn.setOnClickListener()
        {
            divide()
        }
        squareRootBtn.setOnClickListener()
        {
            SquareRoot()
        }
        powerBtn.setOnClickListener()
        {
            Power()
        }

    }

    @SuppressLint("SetTextI18n")
    private fun divide(){

        if (inputRequired() && notZero()) {
            val insert1 = Digit1?.text.toString().trim().toBigDecimal()
            val insert2 = Digit2?.text.toString().trim().toBigDecimal()
           val answer = insert1.divide(insert2,2, RoundingMode.HALF_UP)
            Result?.text = "$insert1 / $insert2 = $answer"
        }
    }

    @SuppressLint("SetTextI18n")
    private fun notZero(): Boolean {

        var z = true

        val insert1 = Digit1?.text.toString().trim().toBigDecimal()
        val insert2 = Digit2?.text.toString().trim().toBigDecimal()

        if (insert1 == BigDecimal.ZERO || insert2 == BigDecimal.ZERO) {
            Result?.text = "Cannot divide by zero"
            z = false
        }
        return z
    }


    @SuppressLint("SetTextI18n")
    private fun add() {

        if (inputRequired()) {
            val insert1 = Digit1?.text.toString().trim().toBigDecimal()
            val insert2 = Digit2?.text.toString().trim().toBigDecimal()
            val answer = insert1.add(insert2)
            Result?.text = "$insert1 + $insert2 = $answer"
        }

    }


    @SuppressLint("SetTextI18n")
    private fun subtract() {
        if (inputRequired()) {
            val insert1 = Digit1?.text.toString().trim().toBigDecimal()
            val insert2 = Digit2?.text.toString().trim().toBigDecimal()
            val answer = insert1.subtract(insert2)
            Result?.text = "$insert1 - $insert2 = $answer"
        }

    }


    @SuppressLint("SetTextI18n")
    private fun multiply() {
        if (inputRequired()) {
            val insert1 = Digit1?.text.toString().trim().toBigDecimal()
            val insert2 = Digit2?.text.toString().trim().toBigDecimal()
            val answer = insert1.multiply(insert2)
            Result?.text = "$insert1 * $insert2 = $answer"
        }

    }


    @SuppressLint("SetTextI18n")
    private fun SquareRoot() {
        if (inputRequired()) {
            val value1 = Digit1?.text.toString().trim().toDouble()
            val value2 = Digit2?.text.toString().trim().toDouble()

            val result1: String = if (value1 < 0) {
                val imaginaryPart = sqrt(-value1)
                "${imaginaryPart}i"
            } else {
                sqrt(value1).toString()
            }

            Result?.text = "Sqr($value1) = $result1"
        }
    }


    @SuppressLint("SetTextI18n")
    private fun Power() {
        if (inputRequired()) {
            val base = Digit1?.text.toString().trim().toDouble()
            val exponent = Digit2?.text.toString().trim().toDouble()

            var result = 1.0
            var calculationString = "$base^$exponent "

            for (i in 1..exponent.toInt()) {
                result *= base
            }

            Result?.text = "$calculationString = $result"
        }
    }


    private fun inputRequired(): Boolean {
        var b = true
        if (Digit1?.text.toString().trim().isEmpty()) {
            Digit1?.error = "please insert a number"
            b = false
        }
        if (Digit2?.text.toString().trim().isEmpty()) {
            Digit2?.error = "please insert a number"
            b = false
        }
        return b
    }

}
/*//References
*//*Kincade Garanganga, KG. (2023), IMAD5112 Lecturer. Varsity College*//*
*//*   w3schools, n.d. w3schools Kotlin Tutorial. [Online]
   Available at: https://www.w3schools.com/kotlin/index.php
   [Accessed 22 September 2023].*/




